import { SortAlphabeticallyPipe } from './sort-alphabetically.pipe';

describe('SortAlphabeticallyPipe', () => {
  it('create an instance', () => {
    const pipe = new SortAlphabeticallyPipe();
    expect(pipe).toBeTruthy();
  });
});
