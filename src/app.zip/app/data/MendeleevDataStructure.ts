export interface MendeleevDataStructure {
    id: string;
    name: string;
    progress: string;
    color: string;
  }